/*
- Seção para mostrar o produto que será incluido no carrinho
  – Id do produto
  – nome do produto
  – Valor unitário
  – valor total da compra
  – imagem do produto

Deverá ter uma seção com a TABLE-HTML contendo a lista de elementos do carrinho de compras do cliente

- Numero sequencia
- Id do produto
- Nome do produto
- Valor unitário
- Valor total
- Botão Remover item
*/

/*
Para carrinho de compras

- ID do cliente
- idProduto (numérico inteiro)
- nomeProduto(Nome curto do produto)
- valor unitário do produto
*/

let cliente = null

document.addEventListener('DOMContentLoaded', (event) => {
  // recebendo usuário
  cliente = localStorage.getItem('LoginCliente')

  if (!cliente) {
    // Mandando para outra página
    alert('Você não tem permissão para entrar nessa página')
    window.location.assign('/index.html')
    return
  }

  cliente = JSON.parse(cliente)

  // Vendo se é necessário colocar o produto que acabou de colocar
  const params = new URLSearchParams(window.location.search)
  const idProduto = params.get('idProduto')
  const quantidadeProduto = params.get('quantidade')

  // Verificando se é necessário colocar o produto que acabou de colocar
  if (idProduto && quantidadeProduto) {
    const secaoAcabouDeAdicionar = document.getElementById('acabou-de-adicionar')

    secaoAcabouDeAdicionar.style.display = 'flex'

    const produtos = JSON.parse(localStorage.getItem('produtosBD'))

    const produto = produtos.find((prod) => prod.idProduto === parseInt(idProduto))

    secaoAcabouDeAdicionar.innerHTML = `
    <div class="acabou-de-adicionar">
      <h1 class="cliente-text">${cliente.nomeCliente}, você adicionou:</h1>
      <div class="produto-card">
        <img src="../${produto.urlImgProduto + produto.nomeArquivoImgProduto}" alt="Imagem do produto" class="produto-card-imagem" />
        <div class="produto-info">
          <h3>${produto.nomeProduto}</h3>
          <p>Id do Produto: ${produto.idProduto}</p>
          <p>Valor unitário: <b>${produto.valorUnitarioProduto}</b></p>
          <p>Valor total: <b>${produto.valorUnitarioProduto * parseInt(quantidadeProduto)}</b></p>
        </div>
      </div>
    </div>
    `
  }

  // Recebendo carrinho de compras
  const carrinho = JSON.parse(localStorage.getItem('CarrinhoCompras'))

  // Recebendo tabela
  const tabela = document.getElementById('lista-produtos')

  // Fazendo iteração
  let tabelaTexto = ''
  carrinho.forEach((prod, index) => {
    tabelaTexto += `
    <tr id="produto${prod.idProduto}">
      <td>${index}</td>
      <td>${prod.idProduto}</td>
      <td>${prod.nomeProduto}</td>
      <td>${prod.valorUnitarioProduto}</td>
      <td>${prod.valorUnitarioProduto * prod.quantidadeProduto}</td>
      <td>
      <button onclick="removerItem(${prod.idProduto})">Remover produto</button>
      </td>
    </tr>
      `
  })

  // Colocando tabela na tela
  tabela.outerHTML = tabelaTexto
})

function encerrarCompra() {
  let numeroCartao = prompt('Digite o número do cartão')

  if (isNaN(parseInt(numeroCartao))) {
    alert('Número do cartão pode somente conter números!')
    return
  }

  let senhaDoCartao = prompt('Digites a senha do cartão:')

  if (isNaN(parseInt(senhaDoCartao))) {
    alert('Senha do cartão pode conter somente números!')
    return
  }

  localStorage.removeItem('CarrinhoCompras')
  alert('Compra realizada com sucesso!')

  window.location.assign('/index.html')
}

// Função para remover item do carrinho
function removerItem(id) {
  // Recebendo carrinho de compras
  const carrinho = JSON.parse(localStorage.getItem('CarrinhoCompras'))

  // Criando novo carrinho de compras
  const novoCarrinhoCompras = []

  carrinho.forEach((prod) => {
    if (prod.idProduto !== id) {
      novoCarrinhoCompras.push(prod)
    }
  })

  // Colocando novo carrinho de compras no localStorage
  localStorage.setItem('CarrinhoCompras', JSON.stringify(novoCarrinhoCompras))

  // Removendo da tela
  document.getElementById(`produto${id}`).outerHTML = ''
}