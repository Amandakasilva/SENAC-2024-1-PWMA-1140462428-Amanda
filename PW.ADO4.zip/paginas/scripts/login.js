document.getElementById('login-form').addEventListener('submit', (event) => {
  event.preventDefault()

  const params = new FormData(event.target)

  const email = params.get('email')
  const senha = params.get('password')

  if (email === '') {
    alert('Atenção; o campo email está vazio')
    return
  }

  if (senha === '') {
    alert('Atenção; o campo senha está vazio')
    return
  }

  const clientes = JSON.parse(localStorage.getItem('clientesBD'))

  for (const cliente of clientes) {
    if (cliente.emailCliente === email && cliente.senhaCliente === senha) {
      const dadosCliente = {
        idCliente: cliente.idCliente,
        emailCliente: cliente.emailCliente,
        nomeCliente: cliente.nomeCliente,
        urlAvatarCliente: cliente.urlAvatarCliente,
        nomeArquivoAvatarCliente: cliente.nomeArquivoAvatarCliente,
      }

      localStorage.setItem('LoginCliente', JSON.stringify(dadosCliente))

      alert('Login feito com sucesso!')
      window.location.assign('/index.html')
      return
    }
  }

  alert('Atenção; você não é nosso cliente, faça seu cadstro')
  window.location.assign('/index.html')
})