const clientesBD = [{
  idCliente: 0,
  emailCliente: 'email@email.com',
  senhaCliente: 'senha123',
  nomeCliente: 'Fulano',
  urlAvatarCliente: 'imagens',
  nomeArquivoAvatarCliente: 'cliente_avatar.png',
}, {
  idCliente: 1,
  emailCliente: 'professor@email.com',
  senhaCliente: 'professorsenha123',
  nomeCliente: 'Professor',
  urlAvatarCliente: 'imagens',
  nomeArquivoAvatarCliente: 'cliente_avatar.png',
}]

const produtosBD = [
  {
    idProduto: 0,
    nomeProduto: 'Cafeteira Philco',
    descricaoProduto: 'Cafeteira incrível que suporta dois cafés ao mesmo tempo da Philco!',
    valorUnitarioProduto: 449.99,
    qtdEstoqueProduto: 100,
    urlImgProduto: 'imagens/produtos/',
    nomeArquivoImgProduto: 'cafeteira_philco.jpg',
  },
  {
    idProduto: 1,
    nomeProduto: 'Computador Completo',
    descricaoProduto: 'Computador de alta performance para jogos e trabalho.',
    valorUnitarioProduto: 2999.99,
    qtdEstoqueProduto: 50,
    urlImgProduto: 'imagens/produtos/',
    nomeArquivoImgProduto: 'computador.jpg',
  },
  {
    idProduto: 2,
    nomeProduto: 'iPad',
    descricaoProduto: 'iPad da Apple com tela Retina e desempenho excepcional.',
    valorUnitarioProduto: 3999.99,
    qtdEstoqueProduto: 30,
    urlImgProduto: 'imagens/produtos/',
    nomeArquivoImgProduto: 'ipad-ipad.jpeg',
  },
  {
    idProduto: 3,
    nomeProduto: 'MacBook Air M1',
    descricaoProduto: 'MacBook Air com chip M1 da Apple para desempenho e eficiência incomparáveis.',
    valorUnitarioProduto: 7999.99,
    qtdEstoqueProduto: 20,
    urlImgProduto: 'imagens/produtos/',
    nomeArquivoImgProduto: 'macbook.jpeg',
  },
  {
    idProduto: 4,
    nomeProduto: 'iPhone 12',
    descricaoProduto: 'iPhone 12 com display Super Retina XDR e câmera de última geração.',
    valorUnitarioProduto: 4999.99,
    qtdEstoqueProduto: 75,
    urlImgProduto: 'imagens/produtos/',
    nomeArquivoImgProduto: 'iphone.jpeg',
  },
  {
    idProduto: 5,
    nomeProduto: 'Samsung Galaxy S24',
    descricaoProduto: 'Samsung Galaxy S24 com tecnologia de ponta e câmera profissional.',
    valorUnitarioProduto: 5999.99,
    qtdEstoqueProduto: 60,
    urlImgProduto: 'imagens/produtos/',
    nomeArquivoImgProduto: 'sansung_s24.png',
  },
  {
    idProduto: 6,
    nomeProduto: 'Televisão Samsung QLED 75 Polegadas',
    descricaoProduto: 'Televisão Samsung QLED de 75 polegadas com resolução 4K UHD.',
    valorUnitarioProduto: 9999.99,
    qtdEstoqueProduto: 15,
    urlImgProduto: 'imagens/produtos/',
    nomeArquivoImgProduto: 'televisao_75.jpg',
  },
  {
    idProduto: 7,
    nomeProduto: 'Smartphone Xiaomi Mi 11 Lite',
    descricaoProduto: 'Smartphone Xiaomi Mi 11 Lite com design elegante e excelente desempenho.',
    valorUnitarioProduto: 2499.99,
    qtdEstoqueProduto: 100,
    urlImgProduto: 'imagens/produtos/',
    nomeArquivoImgProduto: 'xiaomi_mi_11.jpeg',
  }
];


document.addEventListener('DOMContentLoaded', (event) => {
  event.preventDefault()

  // Verificando localStorage
  const clientes = localStorage.getItem('clientesBD')
  const produtos = localStorage.getItem('produtosBD')

  // Validando e colocando se necessário
  if (!clientes) {
    localStorage.setItem('clientesBD', JSON.stringify(clientesBD))
  }

  if (!produtos) {
    localStorage.setItem('produtosBD', JSON.stringify(produtosBD))
  }
})