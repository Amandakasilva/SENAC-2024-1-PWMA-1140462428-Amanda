// Variáveis globais
const produtos = JSON.parse(localStorage.getItem('produtosBD'))

const loginOutput = document.getElementById('output-login') // Output para o login na tela

let cliente = null // Variável global para o usuário atual

let produtoAtual = null // Variável para saber qual produto está no select

// Criando o eventHandler para saber se o usuário está logado
document.addEventListener('DOMContentLoaded', (event) => {
  event.preventDefault()

  // Verificando se o usuário está logado
  cliente = JSON.parse(localStorage.getItem('LoginCliente'))

  if (!cliente) {
    loginOutput.textContent = 'Você não está logado. Logue para ver o catálogo completo'
  } else {
    // Colocando output
    loginOutput.textContent = `Olá, ${cliente.nomeCliente}`
    // Mostrando botão de carrinho
    document.getElementById('botao-carrinho-compras').style.display = 'block'

    // Tirando o botao de Login
    document.getElementById('botao-login').style.display = 'none'

    // Colocando botao de logout
    document.getElementById('logout-button').style.display = 'block'

    // Colocando informações do Cliente
    document.getElementById('informacoes-cliente').style.display = 'flex'
    document.getElementById('informacoes-cliente').style.alignItems = 'center'
    document.getElementById('informacoes-cliente').style.gap = '.5rem'
    document.getElementById('informacoes-cliente-avatar').src = cliente.urlAvatarCliente + '/' + cliente.nomeArquivoAvatarCliente
    document.getElementById('informacoes-cliente-nome').textContent = cliente.nomeCliente

    // Seção de seleção de produtos
    document.getElementById('selecao-produtos').style.display = 'block'
  }

  const quantidadeDeProdutosParaMostrar = cliente ? produtos.length : 3

  // Colocando os produtos na tela
  let produtosTexto = ''
  let iteracao = 0
  produtos.forEach((prod) => {
    if (iteracao >= quantidadeDeProdutosParaMostrar) {
      return
    }

    produtosTexto += `
      <tr>
        <td class="td-nome-produto">
          ${prod.nomeProduto}
        </td>
        <td class="td-descricao-produto">
          ${prod.descricaoProduto}
        </td>
        <td class="td-valor-produto">
          ${prod.valorUnitarioProduto}
        </td>
        <td class="td-quantidade-produto">
          ${prod.qtdEstoqueProduto}
        </td>
        <td>
          <img class="imagem-produto-lista" src="${prod.urlImgProduto}${prod.nomeArquivoImgProduto}" alt="Imagem do produto ${prod.nomeProduto}" />
        </td>
      </tr>
    `

    iteracao++
  })

  document.getElementById('lista-produtos').outerHTML = produtosTexto // Colocando os produtos na tela

  // Configurando seção de seleção de Produtos
  const select = document.getElementById('selecao-produtos-select')

  let options = ''
  produtos.forEach((prod) => {
    options += `
    <option value="${prod.idProduto}">${prod.nomeProduto}</option>
    `
  })

  select.innerHTML = options

  // Fazendo informações sumirem
  document.getElementById('selecao-produtos-nome').style.display = 'none'
  document.getElementById('selecao-produtos-imagem').style.display = 'none'

  select.addEventListener('change', (event) => {
    // Colocando produto atual
    produtoAtual = event.target.value

    const produto = produtos.find((prod) => prod.idProduto === parseInt(produtoAtual))

    // Mostrando as informações
    document.getElementById('selecao-produtos-nome').style.display = 'block'
    document.getElementById('selecao-produtos-imagem').style.display = 'block'

    // Colocando informações na tela
    document.getElementById('selecao-produtos-nome').textContent = produto.nomeProduto
    document.getElementById('selecao-produtos-imagem').src = produto.urlImgProduto + produto.nomeArquivoImgProduto
  })
})

// Função para fazer logout do sitema
function fazerLogout() {
  localStorage.removeItem('LoginCliente')
  window.location.reload()
}

// Função para colocar produto no carrinho de compras
function colocarProdutoNoCarrinho() {
  let carrinho = localStorage.getItem('CarrinhoCompras') || []

  if (typeof carrinho === 'string') {
    carrinho = JSON.parse(carrinho)
  }

  const produto = produtos.find((prod) => prod.idProduto === parseInt(produtoAtual))

  if (!produto) {
    alert('Produto não encontrado')
    return
  }

  let quantidade = null

  try {
    quantidade = parseInt(prompt('Digite a quantidade de produtos'))
  } catch (err) {
    alert('Quantidade inválida! A quantidade precisa ser um número!')
    return
  }

  // Verificando se o produto já existe
  const produtoJáExisteNoCarrinho = carrinho.find((prod) => prod.idProduto === parseInt(produtoAtual))

  if (produtoJáExisteNoCarrinho) {
    const novoCarrinho = []

    carrinho.forEach((prod) => {
      if (prod.idProduto === parseFloat(produtoAtual)) {
        // Se o produto já existir no carrinho, apenas aumentar a quantidade
        prod.quantidadeProduto = prod.quantidadeProduto + quantidade
      }

      novoCarrinho.push(prod)
    })
  } else {
    // Se não, criar um produto novo
    const produtoParaCarrinho = {
      idCliente: cliente.idCliente,
      idProduto: produto.idProduto,
      nomeProduto: produto.nomeProduto,
      valorUnitarioProduto: produto.valorUnitarioProduto,
      quantidadeProduto: quantidade,
    }

    // Colocando novo produto no carrinho
    carrinho.push(produtoParaCarrinho)
  }

  // Colocando carrinho no localStorage
  localStorage.setItem('CarrinhoCompras', JSON.stringify(carrinho))

  // Indo para tela de carrinho de compras
  const url = `/paginas/compor_carrinho.html?idProduto=${produtoAtual}&quantidade=${quantidade}`

  window.location.assign(url)
}